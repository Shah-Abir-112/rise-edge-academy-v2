import { auth, db, fn } from './firebase.js'
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, reauthenticateWithCredential, EmailAuthProvider, updatePassword } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'
import { doc, getDoc, setDoc, getDocs, collection, query, where, updateDoc, serverTimestamp, getCountFromServer } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js'
import { httpsCallable } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js'

const $app = document.getElementById('app')
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
const toast = (m) => { const t = document.getElementById('toast'); t.textContent = m; t.className = 'show'; setTimeout(() => (t.className = ''), 2800) }
const call = (name, data) => httpsCallable(fn, name)(data).then((r) => r.data)
const idEmail = (id) => `${id.trim().toLowerCase()}@id.riseedge.app`   // Login ID → synthetic auth e-mail (see functions/index.js)
const sum = (a) => (a || []).reduce((s, x) => s + x.a, 0), net = (f) => f.amount + sum(f.fine) - sum(f.discount)
const list = async (col, ...w) => (await getDocs(query(collection(db, col), ...w))).docs.map((d) => ({ id: d.id, ...d.data() }))
const count = async (col, ...w) => (await getCountFromServer(query(collection(db, col), ...w))).data().count
const home = { admin: '/admin', teacher: '/teacher', student: '/student' }
const links = {
  admin: [['/admin', 'Dashboard'], ['/admin/registrations', 'Registrations'], ['/admin/fees', 'Fee approvals'], ['/profile', 'Profile']],
  teacher: [['/teacher', 'Dashboard'], ['/admin/fees', 'Fee approvals'], ['/profile', 'Profile']],
  student: [['/student', 'Dashboard'], ['/student/fees', 'Fees'], ['/profile', 'Profile']],
}
let me = null
const go = (p) => { location.hash = p }
const shell = (body) => `<header class="nav"><b>🎓 Rise Edge Academy</b><nav>${links[me.role].map(([h, t]) => `<a href="#${h}">${t}</a>`).join('')}</nav><button class="ghost" data-act="logout">Logout</button></header><main>${body}</main>`

/* ---------------- views ---------------- */
const landing = () => `<main class="hero"><h1>Rise Edge Academy</h1><p>Class 6 – HSC · Science · Arts · Commerce</p><p><a href="#/register">Apply for admission</a> · <a href="#/login">Portal login</a></p></main>`
const loginView = () => `<form class="auth card" data-form="login"><h2>Login</h2><label>Login ID<input name="id" autocapitalize="off" required></label><label>Password<input name="pw" type="password" required></label><button>Login</button><p><a href="#/register">Register (admission)</a></p></form>`
const registerView = () => `<form class="auth card" data-form="register"><h2>Admission / Registration</h2>
  <label>আমি<select name="role"><option value="student">Student</option><option value="teacher">Teacher</option></select></label>
  <label>Full name<input name="name" required></label><label>Email<input name="email" type="email" required></label><label>Phone<input name="phone"></label>
  <label>Class (student)<select name="class"><option value="">—</option>${[6, 7, 8, 9, 10, 11, 12].map((c) => `<option>${c}</option>`).join('')}</select></label>
  <label>Group (Class 9–12)<select name="grp"><option value="">—</option><option>Science</option><option>Arts</option><option>Commerce</option></select></label>
  <label>Subject(s) (teacher)<input name="subjects"></label><button>Submit</button></form>`

async function studentHome() {
  const uid = me.id, b = me.batchId
  const [att, fees, topics, hw, subs, rank] = await Promise.all([
    list('attendance', where('studentId', '==', uid)), list('fees', where('studentId', '==', uid)),
    list('syllabus', where('batchId', '==', b)), list('homework', where('batchId', '==', b)),
    list('hwSubmissions', where('studentId', '==', uid)), call('myRank', { kind: 'attendance' }).catch(() => ({ rank: null })),
  ])
  const W = { P: 1, L: 1, H: 0.5, A: 0 }
  const attPct = att.length ? Math.round((att.reduce((s, x) => s + W[x.status], 0) / att.length) * 100) : 0
  const due = fees.filter((f) => f.status !== 'paid').reduce((s, f) => s + net(f), 0)
  const syl = topics.length ? Math.round((topics.filter((t) => t.doneOn).length / topics.length) * 100) : 0
  const pending = hw.filter((h) => !subs.some((s) => s.hwId === h.id)).length
  const k = [['Attendance', attPct + '%'], ['Fees due', '৳' + due], ['Homework pending', pending], ['Syllabus done', syl + '%'], ['Attendance rank (only you)', rank.rank ? '#' + rank.rank : '—']]
  return shell(`<h2>Welcome back, ${esc(me.name.split(' ')[0])} 👋</h2><div class="kpis">${k.map(([t, v]) => `<div class="card"><b>${esc(v)}</b>${t}</div>`).join('')}</div>`)
}

async function studentFees() {
  const fees = (await list('fees', where('studentId', '==', me.id))).sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0))
  const dues = fees.filter((f) => f.status === 'due')
  const form = dues.length ? `<form class="card" data-form="payreq"><b>💵 ফি পরিশোধ করেছি</b>
    <label>Month<select name="fee">${dues.map((f) => `<option value="${f.id}">${esc(f.label)} · ৳${net(f)}</option>`).join('')}</select></label>
    <label>Amount paid ৳<input name="amount" type="number" min="1" value="${net(dues[0])}" required></label>
    <label>Method<select name="method"><option>bKash</option><option>Nagad</option><option>Rocket</option><option>Cash</option></select></label>
    <label>Transaction ID<input name="trx"></label><button>Send payment request</button></form>` : ''
  return shell(`<h2>Fees</h2>${form}<div class="card"><table><tr><th>Fees</th><th>Status</th><th>Amount</th><th>Discount</th><th>Fine</th><th>Balance</th></tr>${fees.map((f) =>
    `<tr><td>${esc(f.label)}</td><td>${f.status === 'review' ? `Pending (৳${f.reqAmount})` : f.status}</td><td>${f.amount}</td><td>${sum(f.discount)}</td><td>${sum(f.fine)}</td><td>${f.status === 'paid' ? 0 : net(f)}</td></tr>`).join('')}</table></div>`)
}

const profileView = () => shell(`<h2>${esc(me.name)}</h2>${me.tempPassword ? '<div class="card">⚠️ আপনি temporary password ব্যবহার করছেন — নিচে থেকে change করুন।</div>' : ''}
  <form class="card" data-form="account"><b>🔐 Login details</b><label>Login ID<input name="id" value="${esc(me.loginId)}" autocapitalize="off"></label>
  <label>Current password<input name="cur" type="password" required></label><label>New password (min 6)<input name="pw" type="password"></label><label>Confirm new password<input name="cf" type="password"></label><button>Update</button></form>`)

async function adminHome() {
  const c = await Promise.all([count('profiles', where('role', '==', 'student')), count('profiles', where('role', '==', 'teacher')), count('registrations', where('status', '==', 'pending')), count('fees', where('status', '==', 'review'))])
  return shell(`<h2>স্বাগতম, ${esc(me.name)}</h2><div class="kpis">${['Students', 'Teachers', 'Pending registrations', 'Fee approvals'].map((t, i) => `<div class="card"><b>${c[i]}</b>${t}</div>`).join('')}</div>`)
}
async function adminRegs() {
  const rows = await list('registrations', where('status', '==', 'pending'))
  return shell(`<h2>Pending registrations (${rows.length})</h2>${rows.map((r) => `<div class="card"><b>${esc(r.name)}</b> — ${r.role} · ${esc(r.email)} · ${esc(r.phone)}<div>${r.role === 'student' ? `Class ${r.class}${r.grp ? ' · ' + r.grp : ''}` : esc(r.subjects)}</div>
    <div class="row"><button data-act="approve" data-id="${esc(r.id)}">Approve &amp; email login</button><button class="ghost" data-act="reject" data-id="${esc(r.id)}">Reject</button></div></div>`).join('')}`)
}
async function adminFees() {
  const rows = await list('fees', where('status', '==', 'review'))
  return shell(`<h2>Fee approvals (${rows.length})</h2>${rows.map((f) => `<div class="card"><b>${esc(f.studentName)}</b> — ${esc(f.label)}<div>Requested ৳${f.reqAmount} of ৳${net(f)} via ${esc(f.method)} ${f.trx ? '· Trx ' + esc(f.trx) : ''}</div>
    <div class="row"><button data-act="decide" data-id="${f.id}" data-ok="1">Approve &amp; clear</button><button class="ghost" data-act="decide" data-id="${f.id}" data-ok="0">Reject</button></div></div>`).join('')}`)
}
const teacherHome = () => shell(`<h2>স্বাগতম, ${esc(me.name)}</h2><p class="muted">TODO: attendance, homework, online exam, marks entry, syllabus tick-list (see README roadmap).</p>`)

/* ---------------- router ---------------- */
const routes = { '/': landing, '/login': loginView, '/register': registerView, '/student': studentHome, '/student/fees': studentFees, '/profile': profileView, '/admin': adminHome, '/admin/registrations': adminRegs, '/admin/fees': adminFees, '/teacher': teacherHome }
const guard = { '/student': 'student', '/student/fees': 'student', '/admin': 'admin', '/admin/registrations': 'admin', '/admin/fees': 'staff', '/teacher': 'teacher', '/profile': 'any' }
async function render() {
  const p = location.hash.slice(1) || '/', g = guard[p]
  if (g) {
    if (!me) return go('/login')
    if (g === 'staff' ? !['admin', 'teacher'].includes(me.role) : g !== 'any' && g !== me.role) return go(home[me.role])
  } else if (me && p !== '/') return go(home[me.role])
  $app.innerHTML = '<main class="muted">Loading…</main>'
  try { $app.innerHTML = await (routes[p] || landing)() } catch (e) { console.error(e); $app.innerHTML = `<main><p class="err">${esc(e.message)}</p></main>` }
}
window.addEventListener('hashchange', render)
onAuthStateChanged(auth, async (u) => {
  me = null
  if (u) {
    const s = await getDoc(doc(db, 'profiles', u.uid))
    me = s.exists() && s.data().active ? { id: u.uid, ...s.data() } : null
    if (!me) await signOut(auth)
  }
  const p = location.hash.slice(1) || '/'
  if (me && ['/', '/login', '/register'].includes(p)) go(home[me.role]); else render()
})

/* ---------------- actions & forms ---------------- */
const acts = {
  logout: () => signOut(auth).then(() => go('/login')),
  approve: async (d) => { try { const r = await call('approveRegistration', { id: d.id }); toast('Approved — ' + r.loginId); render() } catch (e) { toast(e.message) } },
  reject: async (d) => { await updateDoc(doc(db, 'registrations', d.id), { status: 'rejected' }); render() },
  decide: async (d) => { try { await call('decideFee', { feeId: d.id, ok: d.ok === '1' }); toast(d.ok === '1' ? 'Approved — fee cleared ✓' : 'Rejected'); render() } catch (e) { toast(e.message) } },
}
const forms = {
  login: async (f) => { try { await signInWithEmailAndPassword(auth, idEmail(f.get('id')), f.get('pw')) } catch { toast('ID বা password ভুল') } },
  register: async (f, form) => {
    const email = f.get('email').trim().toLowerCase(), role = f.get('role'), cls = Number(f.get('class')) || null, grp = f.get('grp') || null
    if (role === 'student' && (!cls || (cls >= 9 && !grp))) return toast('Class / Group select করুন')
    try {
      await setDoc(doc(db, 'registrations', email), { name: f.get('name').trim(), email, phone: f.get('phone') || '', role, class: role === 'student' ? cls : null, grp: role === 'student' && cls >= 9 ? grp : null, subjects: role === 'teacher' ? f.get('subjects') || '' : '', status: 'pending', createdAt: serverTimestamp() })
      form.outerHTML = '<div class="auth card"><h2>✅ Registration পাঠানো হয়েছে</h2><p>Admin approve করলে আপনার email-এ Login ID ও temporary password যাবে।</p></div>'
    } catch { toast('এই email আগেই registered / pending, অথবা তথ্য ভুল') }
  },
  payreq: async (f) => { try { await call('requestFee', { feeId: f.get('fee'), amount: Number(f.get('amount')), method: f.get('method'), trx: f.get('trx') }); toast('Request পাঠানো হয়েছে ✓'); render() } catch (e) { toast(e.message) } },
  account: async (f) => {
    const np = f.get('pw'), id = f.get('id').trim()
    try { await reauthenticateWithCredential(auth.currentUser, EmailAuthProvider.credential(auth.currentUser.email, f.get('cur'))) } catch { return toast('Current password ভুল') }
    if (np) { if (np.length < 6) return toast('Password কমপক্ষে ৬ অক্ষর'); if (np !== f.get('cf')) return toast('Confirm password মেলেনি'); await updatePassword(auth.currentUser, np) }
    try {
      await call('updateAccount', { loginId: id, passwordChanged: !!np })
      me = { id: me.id, ...(await getDoc(doc(db, 'profiles', me.id))).data() }
      toast('Updated ✓ — পরের বার নতুন ID দিয়ে login করুন'); render()
    } catch (e) { toast(e.message) }
  },
}
document.addEventListener('submit', (e) => { const h = forms[e.target.dataset.form]; if (h) { e.preventDefault(); h(new FormData(e.target), e.target) } })
document.addEventListener('click', (e) => { const b = e.target.closest('[data-act]'); if (b) acts[b.dataset.act](b.dataset) })

// Firebase console → Project settings → Your apps → Web app → SDK config (these values are public identifiers, safe to commit).
export const firebaseConfig = {
  apiKey: 'PASTE_API_KEY',
  authDomain: 'YOUR_PROJECT_ID.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_PROJECT_ID.firebasestorage.app',
  messagingSenderId: 'PASTE',
  appId: 'PASTE',
}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'
import { getAuth, connectAuthEmulator } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'
import { getFirestore, connectFirestoreEmulator } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js'
import { getFunctions, connectFunctionsEmulator } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js'
import { firebaseConfig } from './firebase-config.js'

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app), db = getFirestore(app), fn = getFunctions(app, 'asia-south1')
// On localhost the app talks to the free local emulators (npm run emulators) — no billing, no real data.
if (location.hostname === 'localhost') {
  connectAuthEmulator(auth, 'http://localhost:9099')
  connectFirestoreEmulator(db, 'localhost', 8080)
  connectFunctionsEmulator(fn, 'localhost', 5001)
}

// One-time: create the first admin.
//   cd functions && npm install
//   GCLOUD_PROJECT=your-project-id GOOGLE_APPLICATION_CREDENTIALS=../serviceAccount.json \
//     node scripts/create-admin.js "Noman Islam Raj" you@email.com 'StrongPassword1'
// (Login ID will be "admin". For the emulator add FIREBASE_AUTH_EMULATOR_HOST=localhost:9099 FIRESTORE_EMULATOR_HOST=localhost:8080)
const { initializeApp } = require('firebase-admin/app')
const { getAuth } = require('firebase-admin/auth')
const { getFirestore, FieldValue } = require('firebase-admin/firestore')
initializeApp({ projectId: process.env.GCLOUD_PROJECT })
;(async () => {
  const [name, email, password] = process.argv.slice(2)
  if (!name || !email || !password) throw new Error('usage: node scripts/create-admin.js "Name" email password')
  const u = await getAuth().createUser({ email: 'admin@id.riseedge.app', password, emailVerified: true, displayName: name })
  await getAuth().setCustomUserClaims(u.uid, { role: 'admin', batch: null })
  await getFirestore().doc(`profiles/${u.uid}`).set({ role: 'admin', loginId: 'admin', loginKey: 'admin', name, email, phone: '', batchId: null, details: {}, tempPassword: false, active: true, createdAt: FieldValue.serverTimestamp() })
  console.log('Admin created. Login ID: admin')
})().catch((e) => { console.error(e.message); process.exit(1) })

// Seeds the Bangla NCTB chapter lists (syllabus-data.json) for every batch.  Same env vars as create-admin.js.
const { initializeApp } = require('firebase-admin/app')
const { getFirestore } = require('firebase-admin/firestore')
const TP = require('./syllabus-data.json')
initializeApp({ projectId: process.env.GCLOUD_PROJECT })
const GRP = ['Science', 'Arts', 'Commerce']
const JN = ['Bangla', 'English', 'Math', 'Science', 'BGS', 'ICT', 'Religion']
const GS = {
  9: { Science: ['Physics', 'Chemistry', 'Biology', 'Higher Math'], Arts: ['Economics', 'Civics', 'Geography', 'History', 'General Science'], Commerce: ['Accounting', 'Finance & Banking', 'Business Entrepreneurship', 'General Science'] },
  11: { Science: ['Physics 1st', 'Physics 2nd', 'Chemistry 1st', 'Chemistry 2nd', 'Biology (HSC)', 'Higher Math 1st', 'Higher Math 2nd'], Arts: ['Civics', 'Economics', 'Logic', 'Islamic History', 'Sociology'], Commerce: ['Accounting (HSC)', 'Business Org & Mgmt', 'Production & Marketing', 'Finance, Banking & Insurance', 'Statistics'] },
}
const subjects = (c, g) => c < 9 ? JN : [...(c < 11 ? ['Bangla', 'English', 'General Math', 'ICT', 'Religion'] : ['Bangla', 'English', 'ICT']), ...GS[c < 11 ? 9 : 11][g]]
;(async () => {
  const w = getFirestore().bulkWriter(); let n = 0
  for (let c = 6; c <= 12; c++) for (const g of (c < 9 ? [null] : GRP)) {
    const batchId = g ? `${c}-${g}` : String(c)
    for (const subject of subjects(c, g)) (TP[subject] || '').split('|').filter(Boolean).forEach((title, i) => {
      w.set(getFirestore().doc(`syllabus/${batchId}__${subject}__${String(i).padStart(2, '0')}`), { batchId, subject, title, pos: i, doneOn: null }); n++
    })
  }
  await w.close(); console.log('seeded', n, 'topics')
})()

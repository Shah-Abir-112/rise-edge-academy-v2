// Privileged logic lives here (Admin SDK bypasses security rules, so every function checks the caller's role first).
const { onCall, HttpsError } = require('firebase-functions/v2/https')
const { initializeApp } = require('firebase-admin/app')
const { getAuth } = require('firebase-admin/auth')
const { getFirestore, FieldValue } = require('firebase-admin/firestore')
const crypto = require('crypto')

initializeApp()
const auth = getAuth(), db = getFirestore()
const opts = { region: 'asia-south1' }                       // keep in sync with public/firebase.js
const emailFor = (loginId) => `${loginId.toLowerCase()}@id.riseedge.app`   // synthetic auth e-mail; real e-mail is in profiles.email

const need = (req, ...roles) => {
  const r = req.auth?.token?.role
  if (!req.auth || (roles.length && !roles.includes(r))) throw new HttpsError('permission-denied', 'forbidden')
  return req.auth.uid
}
const tempPw = () => Array.from(crypto.randomBytes(8), (b) => 'abcdefghjkmnpqrstuvwxyz23456789'[b % 31]).join('')
const sum = (a = []) => a.reduce((s, x) => s + x.a, 0)
const net = (f) => f.amount + sum(f.fine) - sum(f.discount)
// Writes to /mail → the "Trigger Email from Firestore" extension sends it (README step 6). Also works as a sent-mail log.
const mail = (to, subject, text) => db.collection('mail').add({ to: [to], message: { subject, text } })
const nextId = (key, start, prefix) => db.runTransaction(async (t) => {
  const ref = db.doc('meta/counters'), s = await t.get(ref)
  const n = (s.data()?.[key] ?? start - 1) + 1
  t.set(ref, { [key]: n }, { merge: true })
  return prefix + n
})

// ---------- admin: approve a registration → auth user + profile + fees + login e-mail ----------
exports.approveRegistration = onCall(opts, async (req) => {
  need(req, 'admin')
  const ref = db.doc(`registrations/${req.data.id}`), snap = await ref.get()
  if (!snap.exists || snap.data().status !== 'pending') throw new HttpsError('failed-precondition', 'not pending')
  const r = snap.data(), student = r.role === 'student'
  const loginId = await nextId(student ? 'student' : 'teacher', student ? 2401 : 105, student ? 'REA-' : 'T-')
  const pw = tempPw()
  const batch = student ? (r.class >= 9 ? `${r.class}-${r.grp}` : String(r.class)) : null
  const user = await auth.createUser({ email: emailFor(loginId), password: pw, emailVerified: true, displayName: r.name })
  await auth.setCustomUserClaims(user.uid, { role: r.role, batch })
  const month = new Date().toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })
  const wb = db.batch()
  wb.set(db.doc(`profiles/${user.uid}`), {
    role: r.role, loginId, loginKey: loginId.toLowerCase(), name: r.name, email: r.email, phone: r.phone || '',
    batchId: batch, details: r.subjects ? { subjects: r.subjects } : {}, tempPassword: true, active: true, createdAt: FieldValue.serverTimestamp(),
  })
  if (student) for (const [label, amount] of [['Admission', 2000], [month, 1500]])
    wb.set(db.collection('fees').doc(), { studentId: user.uid, studentName: r.name, batchId: batch, label, amount, fine: [], discount: [], status: 'due', createdAt: FieldValue.serverTimestamp() })
  wb.update(ref, { status: 'approved' })
  await wb.commit()
  await mail(r.email, 'Your Rise Edge Academy login',
    `Assalamu alaikum ${r.name},\n\nLogin ID: ${loginId}\nTemporary password: ${pw}\n\nLogin করে Profile থেকে ID ও password change করুন।\n— Rise Edge Academy`)
  return { loginId }
})

exports.resetPassword = onCall(opts, async (req) => {
  need(req, 'admin')
  const s = await db.doc(`profiles/${req.data.uid}`).get(), p = s.data(), pw = tempPw()
  await auth.updateUser(req.data.uid, { password: pw })
  await s.ref.update({ tempPassword: true })
  await mail(p.email, 'Your new temporary password', `Login ID: ${p.loginId}\nTemporary password: ${pw}`)
  return { ok: true }
})

// ---------- user: change Login ID (password is changed on the client after re-auth) ----------
exports.updateAccount = onCall(opts, async (req) => {
  const uid = need(req)
  if (Date.now() / 1000 - req.auth.token.auth_time > 300) throw new HttpsError('unauthenticated', 'আবার login করে চেষ্টা করুন')
  const { loginId, passwordChanged } = req.data
  if (!/^[A-Za-z0-9._-]{4,20}$/.test(loginId || '')) throw new HttpsError('invalid-argument', 'ID: 4–20 অক্ষর (letter, number, . _ -)')
  const key = loginId.toLowerCase(), ref = db.doc(`profiles/${uid}`), p = (await ref.get()).data()
  if (key !== p.loginKey) {
    if (!(await db.collection('profiles').where('loginKey', '==', key).limit(1).get()).empty) throw new HttpsError('already-exists', 'এই ID আগেই নেওয়া')
    await auth.updateUser(uid, { email: emailFor(key) })
  }
  await ref.update({ loginId, loginKey: key, ...(passwordChanged ? { tempPassword: false } : {}) })
  return { ok: true }
})

// ---------- fees: student request (month + amount) → staff approval clears it ----------
exports.requestFee = onCall(opts, async (req) => {
  const uid = need(req, 'student'), { feeId, amount, method, trx } = req.data
  await db.runTransaction(async (t) => {
    const ref = db.doc(`fees/${feeId}`), s = await t.get(ref), f = s.data()
    if (!s.exists || f.studentId !== uid || f.status !== 'due') throw new HttpsError('failed-precondition', 'fee not found')
    const a = Number(amount)
    if (!(a >= 1 && a <= net(f))) throw new HttpsError('invalid-argument', 'Amount due-এর বেশি হতে পারে না')
    t.update(ref, { status: 'review', reqAmount: a, method: String(method).slice(0, 20), trx: String(trx || '').slice(0, 60) })
  })
  return { ok: true }
})

exports.decideFee = onCall(opts, async (req) => {
  need(req, 'admin', 'teacher')
  const { feeId, ok } = req.data
  await db.runTransaction(async (t) => {
    const ref = db.doc(`fees/${feeId}`), s = await t.get(ref), f = s.data()
    if (!s.exists || f.status !== 'review') throw new HttpsError('failed-precondition', 'no pending request')
    const n = net(f), a = Math.min(f.reqAmount || n, n), del = { reqAmount: FieldValue.delete() }
    if (!ok) t.update(ref, { status: 'due', method: FieldValue.delete(), trx: FieldValue.delete(), ...del })
    else if (a >= n) t.update(ref, { status: 'paid', paidAt: FieldValue.serverTimestamp(), ...del })
    else {   // partial: "(part)" paid line + the remainder stays due
      const { reqAmount, ...base } = f
      t.set(db.collection('fees').doc(), { ...base, label: f.label + ' (part)', amount: a, fine: [], discount: [], status: 'paid', paidAt: FieldValue.serverTimestamp() })
      t.update(ref, { amount: n - a, fine: [], discount: [], status: 'due', method: FieldValue.delete(), trx: FieldValue.delete(), ...del })
    }
  })
  return { ok: true }
})

// ---------- online exam: questions without answers; grading on the server ----------
exports.getExamQuestions = onCall(opts, async (req) => {
  const uid = need(req, 'student'), id = req.data.examId
  const e = (await db.doc(`onlineExams/${id}`).get()).data()
  if (!e || e.batchId !== req.auth.token.batch) throw new HttpsError('permission-denied', 'forbidden')
  const used = (await db.collection('attempts').where('examId', '==', id).where('studentId', '==', uid).get()).size
  if (used >= e.attempts) throw new HttpsError('failed-precondition', 'Attempt শেষ')
  const qs = await db.collection(`onlineExams/${id}/questions`).get()
  return { exam: { title: e.title, durationMin: e.durationMin, negative: e.negative }, questions: qs.docs.map((d) => ({ id: d.id, q: d.data().q, options: d.data().options })) }
})
exports.submitAttempt = onCall(opts, async (req) => {
  const uid = need(req, 'student'), { examId, answers = {} } = req.data
  const e = (await db.doc(`onlineExams/${examId}`).get()).data()
  if (!e || e.batchId !== req.auth.token.batch) throw new HttpsError('permission-denied', 'forbidden')
  const qs = (await db.collection(`onlineExams/${examId}/questions`).get()).docs
  let correct = 0, wrong = 0
  qs.forEach((d) => { const a = answers[d.id]; if (a === undefined) return; a === d.data().answer ? correct++ : wrong++ })
  const score = correct - wrong * (e.negative || 0)
  await db.collection('attempts').add({ examId, studentId: uid, batchId: e.batchId, answers, correct, wrong, score, total: qs.length, createdAt: FieldValue.serverTimestamp() })
  return { correct, wrong, score, total: qs.length }
})

// ---------- rank privacy: returns ONLY the caller's rank ----------
exports.myRank = onCall(opts, async (req) => {
  const uid = need(req, 'student'), batch = req.auth.token.batch, W = { P: 1, L: 1, H: 0.5, A: 0 }
  const rows = req.data.kind === 'exam'
    ? (await db.collection('examMarks').where('batchId', '==', batch).get()).docs.map((d) => ({ s: d.data().studentId, v: d.data().marks / d.data().max }))
    : (await db.collection('attendance').where('batchId', '==', batch).get()).docs.map((d) => ({ s: d.data().studentId, v: W[d.data().status] }))
  const by = {}; rows.forEach((r) => (by[r.s] ||= []).push(r.v))
  const avg = Object.entries(by).map(([k, a]) => [k, a.reduce((x, y) => x + y, 0) / a.length]).sort((a, b) => b[1] - a[1])
  const me = avg.find(([k]) => k === uid)
  return me ? { rank: 1 + avg.findIndex(([, v]) => v === me[1]), of: avg.length } : { rank: null, of: avg.length }
})

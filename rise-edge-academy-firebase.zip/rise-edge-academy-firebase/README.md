# Rise Edge Academy — Git + Firebase

Static front-end (Firebase Hosting) + Firebase Auth + Firestore + Cloud Functions + Storage. Deploys from GitHub on every push to `main`.
**Status:** a working vertical slice, *not yet run against a real Firebase project* — expect small fixes on first run. `prototype/index.html` is the full-UI prototype to port the remaining screens from.

## Run it locally first (free, no billing)
```bash
npm i -g firebase-tools && firebase login
cd functions && npm install && cd ..
firebase emulators:start                 # Auth, Firestore, Functions, Hosting → http://localhost:5000
# new terminal, create the admin inside the emulator:
cd functions && FIREBASE_AUTH_EMULATOR_HOST=localhost:9099 FIRESTORE_EMULATOR_HOST=localhost:8080 GCLOUD_PROJECT=demo-riseedge node scripts/create-admin.js "Noman Islam Raj" you@email.com 'StrongPass1'
```
Open http://localhost:5000 → Login ID `admin`. Register a student in another tab, approve as admin; the "email" appears in the Firestore emulator UI (collection `mail`).

## Go live
1. Firebase console → create project → enable **Authentication → Email/Password**, **Firestore** (location `asia-south1`), **Storage**.
2. Upgrade to the **Blaze** plan (needed for Cloud Functions; the free quota normally covers a small coaching centre).
3. Project settings → add a **Web app** → paste the config into `public/firebase-config.js`; put your project id in `.firebaserc`.
4. `git init && git add . && git commit -m "init"` → create a GitHub repo → push to `main`.
5. GitHub → Settings → Secrets and variables → Actions: secret `FIREBASE_SERVICE_ACCOUNT` (service-account JSON with roles *Firebase Admin*, *Cloud Functions Admin*, *Service Account User*) and variable `FIREBASE_PROJECT_ID`. Every push now deploys everything (`.github/workflows/deploy.yml`). First time you can also run `firebase deploy` by hand.
6. Real e-mails: Extensions → install **Trigger Email from Firestore** (collection `mail`, SMTP / SendGrid / Gmail app-password). Until then mails are only stored in `mail`.
7. Create the first admin with `functions/scripts/create-admin.js` (see top of the file; use a service-account key + `GCLOUD_PROJECT`) and optionally `seed-syllabus.js` (Bangla NCTB chapters for every batch).

## How login works
Firebase Auth needs an e-mail, so each account's auth e-mail is **`<loginId>@id.riseedge.app`** (never delivered to). The real e-mail is stored in `profiles.email` and used for mails. Students/teachers type their Login ID; changing the ID updates the auth e-mail via a Cloud Function. Forgot password = admin **resetPassword** (new temp password mailed) — Firebase's own reset mail can't reach the fake address.
Role and batch are **custom claims** in the token, so security rules need no extra reads.

## Implemented
Public registration → admin approve (auth user + claims + profile + fees + login mail) · login by ID · change ID/password · fee request (month + amount + method + trx) → staff approve/reject (partial → "(part)" split, transactional) · student KPI dashboard · private rank (`myRank` returns only the caller's rank) · server-graded online exam functions (`getExamQuestions`, `submitAttempt`) · rules for every collection.

## Roadmap (collections are already covered by `firestore.rules`)
`attendance`+`holidays` · `syllabus` (seed script, teacher tick = set `doneOn`) · `homework`+`hwSubmissions` (files → Storage `uploads/<uid>/…`) · `exams`+`examMarks` (store `batchId`, `max` on each mark for `myRank`) · `onlineExams`(+`questions`) UI · `leaves`, `requests`, `library`, `notices`, `contents`, `timetable` · fine/discount editor · monthly fee generation · Bangla/English toggle.
Rules: any new batch-wise collection just needs a `batchId` field and its name added to the list in `firestore.rules`.
